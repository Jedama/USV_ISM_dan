#from multiprocessing import Process
import sys
sys.path.remove('/opt/ros/kinetic/lib/python2.7/dist-packages')

import Simulation as sp
import SNN_network as SNN
import environment as env
import numpy as np
import math

#import torch
#import matplotlib.animation as animation

def angle_saturation(sensor):
    if sensor > 180:
        sensor = sensor - 360
    if sensor < -180:
        sensor = sensor + 360
    return sensor


# Serial port
port_name='interface_1'		#File created at /SNN_Codes/Port by Serial_Port.sh
direction= '/home/dan/SS/SNN_Codes/Port'  #Path to interfaces
timeout=15  
p = sp.serial_port(direction, port_name, timeout) #Open port
# Sensor ranges

waypoints = [
    [(250.0, 90.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
    [(260.0, 100.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
    [(270.0, 110.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
    [(280.0, 100.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
    [(290.0, 90.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
    [(300.0, 100.0, 0.0), (0.0, 0.0, 0.0, 1.0)],
    [(350.0, 150.0, 0.0), (0.0, 0.0, 0.0, 1.0)]
]

UseSNN = 0
GPSref = (-1, -1)
vmax=[500, 180, 30, 30, 180]
vmin=[0, -180, -30, -30, -180]
AM=[20,90]
Am=[-20,-90]
# Size step of algorithm
PMax = 1
Pmin = 0.01
step = 5e-1
# Simulation and control times
factor_time = 1
simul_time = 3
reward_time = simul_time/factor_time
time_network=250
# Network characteristics and connections
dt=1
control_signals=4
number_actuators=1
min_freq=0
max_freq=1
codify = 'bernoulli'
#dato=[1,1,0,1,1,1]
#dato=[0.9, 1, 0.6, 0.8, 0.3]
#dato=[0.8,0.51,0.33,0.22,0.1]
neur=[control_signals*2, 15,number_actuators]

i= input("Do you want to load a network  (0) or create a new one (1)?")

if i=='1':

    max_spikes,min_spikes = SNN.max_min_spikes(neuronas=neur,
                                dt=dt,
                                time=time_network,
                                recurrent=0,
                                modelo='LIF',
                                wM = PMax,
                                wm = Pmin,
                                n = step,
                                codify = codify,         
                                maximum = max_freq,
                                minimun = min_freq
                                )
    
    [capas,monitores,net, m_pesos] = SNN.arquitectura_red(neuronas=neur,
                                              dt=dt,
                                              time=time_network,
                                              recurrent=0,
                                              modelo='LIF',
                                              wM = PMax,
                                              wm = Pmin,
                                              n = step
                                              )


else:
    
    [capas,monitores,net, m_pesos, max_spikes, min_spikes, neur] = SNN.cargar_red(name='red_prueba.pt', 
                                                                                  direction=direction, 
                                                                                  learning = True)
    
# data = SNN.codificacion_red('bernoulli',time_network,dt,dato)
# net.run(inputs={capas[0] : data}, time=time_network,reward=0)
# uu=SNN.decode_spikes(monitores[1],max_spikes,AM,Am,10)
#SNN.imprimir_spikes(monitores,time_network,None,None)

#im = SNN.imprimir_pesos(m_pesos,10,0,None)
#print(uu)

#SNN controller
band=False	#Band = flag
rew = [0,0]	#Reward?
s1=None		#??
s2=None		#??
im=None		#??
restart=2	#Flag for when to restart
state = 0	#Controls which waypoint is next
saving = 0	#Saving network to file
# band=p.open_port()
# while True:
#     p.classic_controller()

while True:
    if not band:	#Open port if not already open
        band=p.open_port()	#Band is flag for whether the port was correctly opened
    else:
        #p.classic_controller()
        dato=p.read_data_sensor()	#dato = [flag if data was correctly read, xpos, ypos, xgoal, ygoal, roll, pitch, yaw, wind angle]
        ro,r = env.get_plane(dato)
        env.carril_velero(ro,r,0.5)
        if (UseSNN == 0):

            if not isinstance(dato,bool):

                if GPSref == (-1, -1):

                    GPSref = (dato[1], dato[2])

                

                #Translate lat/lng to meters
                dato[1] = (6378137 * math.pi * (dato[1] - GPSref[0]))/180
                dato[2] = (6378137 * math.pi * math.cos((math.pi * GPSref[0])/180) * (dato[2] - GPSref[1]))/180

                dato[1] += 230
                dato[2] += 100

                control_action = [0,0,0]
                

                #Rudder control
                dato[3] = waypoints[state][0][0]
                dato[4] = waypoints[state][0][1]

                print(dato)

                sp_angle=math.degrees(math.atan2(dato[4]-dato[2],dato[3]-dato[1]))
                target_angle = math.degrees(dato[7])

                sp_angle = -angle_saturation(sp_angle)
                target_angle = -angle_saturation(target_angle)

                err_ang = sp_angle - target_angle
                err_ang = angle_saturation(err_ang)

                control_action[0] = err_ang / 2

                #Sail control
                sail_angle = dato[8] / 2
                
                if sail_angle < -80:
                    sail_angle = -sail_angle
                
                control_action[1] = -sail_angle

                #Distance to next waypoint
                err_dist = np.sqrt((dato[1]-dato[3])**2+(dato[2]-dato[4])**2)

                if err_dist < 3:
                    control_action[2] = 1
                    state += 1
                else:
                    control_action[2] = 0

                #Send back to USV_SIM
                print(control_action)
                p.write_control_action(control_action) #Send control actions to USV_SIM
            
            else:
                print("No new data")
            

        else:
            if not isinstance(dato,bool):
                [n_dato,re] = env.control_inputs(dato,vmax,vmin, state, max_freq, min_freq); #n_dato = [err_ang, roll, pitch, wind_dir] normalized, re = reward (err_dist)
                print(n_dato[3])
                rew[1] = re #rew[1] = reward (err_dist)
                if restart==2:
                    state = 0 #Restarts the simulation?
                    print('Should restart')
                if restart ==2 or restart ==1:	 #What is the purpose of all this?
                    ro,r = env.get_plane(dato)       #ro = origin point, r = goal point  
                    env.carril_velero(ro,r,0.5)	 #Does this create new 'rails'????
                    r=0 				 #???
                    net.reset_state_variables()      #Resets SNN network?
                else:        
                    r = env.reward(rew,1,limit = 1) #reward
                    #r = env.reward(dato,2,limit = 1)
                n_dato = n_dato+list(max_freq*env.np.ones(len(n_dato))) #Append four ones at the end of n_dato?
                print(n_dato)
                print(re)
                #cod_n_dato = SNN.codificacion_red('bernoulli',1,dt,n_dato)
                #net.run(inputs={capas[0] : cod_n_dato}, time=1, reward=-1)
                cod_n_dato = SNN.codificacion_red(codify,time_network,dt,n_dato) #?????????
                net.run(inputs={capas[0] : cod_n_dato}, time=time_network, reward=r) #????????
                control_action=SNN.decode_spikes(monitores[len(neur)-1],[max_spikes,min_spikes],AM,Am,rew[1]) #Control action = [??, 0, final] final = 1 if goal reached
                control_action[2] = env.is_restart([dato[1],dato[2]], control_action[2]) #Check if outside boundaries
                print(control_action)
                p.write_control_action(control_action) #Send control actions to USV_SIM
                SNN.imprimir_spikes(monitores,time_network,s1,s2) #Print spikes
                SNN.imprimir_pesos(m_pesos, wmax=PMax, wmin=Pmin, im=im) #Print weights
                if(control_action[2]==1): #Control_action[2]==1 means we've reached goal
                    state += 1
                    if saving < state:
                        SNN.guardar_red('red_prueba.pt',net,direction,max_spikes,min_spikes,neur) #Network_test.pt
                        saving +=1
            
                rew[0]=rew[1]
                restart = control_action[2]
            else:
                print("No new data")

# ztraining = Process(target=SNN_training)
# graph = Process(target=Graphs_generator,args=(False,))
# monitores = []
# 
# graph.start()
# training.start()
