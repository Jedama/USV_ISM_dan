#!/bin/bash
cd /home/dan/SS/SNN_Codes/Port
socat pty,link=interface_1,raw,echo=1 pty,link=interface_2,raw,echo=1
